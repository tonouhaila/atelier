#include<iostream>
using namespace std;
class MyClass{
    public:
     MyClass();
     ~MyClass();
};
MyClass::MyClass(){
    cout<<"c'est un constructeur\n";
}
MyClass::~MyClass(){
    cout<<"c'est un destructeur , la dueée de cette objet est terminé\n";
}
main(){
    MyClass objet1;
    cout<<"l'objet est créer\n";
}