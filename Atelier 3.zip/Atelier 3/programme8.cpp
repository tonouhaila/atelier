#include <iostream>
using namespace std;
class media{
    private:
     string titre;
    public:
     virtual void imprimer();
     virtual char *id();
};
class Audio : public media{};
class livre : public media{};
class presse : public media{};
class CD : public Audio{};
class Cassette : public Audio{};
class Disque : public Audio{};
class magasine : public presse{};
class journal : public presse{};
class revue : public presse{};