#include <iostream>
using namespace std;

class Shape
{
private:
  float x, y;
public:
  Shape(float x, float y)
  {
    x = x;
    y = y;
  }
};

class Rectangle: public Shape
{
public:
  Rectangle(float x, float y) : Shape(x, y) {}

  float area()
  {
    return (x * y);
  }
};

class Triangle: public Shape
{
public:
  Triangle(float x, float y) : Shape(x, y) {}

  float area()
  {
    return (x * y / 2);
  }
};

int main (){

  Rectangle rectangle(6,4);
  Triangle triangle(6,4);
  cout <<"l'aire du rectangle est :"<<rectangle.area() << endl;   
  cout <<"l'aire du triangle est :"<< triangle.area() << endl;    
  return 0;
}