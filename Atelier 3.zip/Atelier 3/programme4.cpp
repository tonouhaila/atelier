#include <iostream>
using namespace std;
class mere{
public:
  void display ()
  {
    cout << "La classe mere contient la méthode display \n";
  }
};

class fille : public mere{
public:
  void display ()
  {
    cout << "La classe fille héritée contient la méthode display \n";
  }
};

int main ()
{
  fille OBJ;
  OBJ.display();
  return 0;
}